/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.model.Producto;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class ProductoDAOJDBimpl implements ProductoDAO{
    private static final String SELECTPRODUCTOS = "SELECT * FROM PRODUCTOS";
    private static final String INSERTPRODUCTO = "INSERT INTO `productos`(`ID_Producto`, `Descripcion`, `StockActual`, `PVP`) VALUES (NULL, ?, ?, ?)";

    @Override
    public ArrayList<Producto> list(Connection con) throws DAOException {
        try (Statement stmt = con.createStatement()) {
            ResultSet rs = stmt.executeQuery(SELECTPRODUCTOS);

            ArrayList<Producto> producto = new ArrayList<>();

            while (rs.next()) {
                producto.add(new Producto(rs.getInt("ID_PRODUCTO"), rs.getString("DESCRIPCION"), rs.getInt("STOCKACTUAL"), rs.getDouble("PVP")));
            }

            return producto;
        } catch (SQLException se) {
            throw new DAOException("Error getting all Clients in DAO");
        }}

    @Override
    public void add(Producto producto, Connection con) throws DAOException {
        try (PreparedStatement stmt = con.prepareStatement(INSERTPRODUCTO)) {
            stmt.setString(1, producto.getDescripcion());
            stmt.setInt(2, producto.getStock());
            stmt.setDouble(3, producto.getPvp());

            if (stmt.executeUpdate() != 1) {
                throw new DAOException("Error adding producto");
            }
        } catch (SQLException se) {
            throw new DAOException("Error adding in DAO");
        }
    }

}
