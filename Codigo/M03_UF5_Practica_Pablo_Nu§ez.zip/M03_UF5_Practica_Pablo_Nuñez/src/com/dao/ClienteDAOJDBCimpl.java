/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * @author Pablo
 */
public class ClienteDAOJDBCimpl implements ClienteDAO {
    private static final String SELECTCLIENTES = "SELECT * FROM CLIENTES";
    private static final String INSERTCLIENTE = "INSERT INTO CLIENTES VALUES(?,?,?,?,?,?,?)";
    private static final String SELECTCLIENTE = "SELECT * FROM clientes WHERE ID_Cliente = ?";

    @Override
    public ArrayList<Cliente> list(Connection con) throws DAOException {
        try (Statement stmt = con.createStatement()) {
            ResultSet rs = stmt.executeQuery(SELECTCLIENTES);

            ArrayList<Cliente> clients = new ArrayList<>();

            while (rs.next()) {
                clients.add(new Cliente(rs.getString("ID_CLIENTE"), rs.getString("DNI"), rs.getString("NOMBRE"), rs.getString("DIRECCION"), rs.getString("POBLACION"), rs.getString("TELF")));
            }

            return clients;
        } catch (SQLException se) {
            throw new DAOException("Error getting all Clients in DAO");
        }
    }

    @Override
    public void add(Connection con, Cliente cliente) throws DAOException {
        try (PreparedStatement stmt = con.prepareStatement(INSERTCLIENTE)) {
            stmt.setString(1, null);
            stmt.setString(2, cliente.getDni());
            stmt.setString(3, cliente.getNombre());
            stmt.setString(4, cliente.getDireccion());
            stmt.setString(5, cliente.getPoblacion());
            stmt.setString(6, cliente.getTelefono());
            stmt.setString(7, cliente.getDate());
            if (stmt.executeUpdate() != 1) {
                throw new DAOException("Error adding venta");
            }
        } catch (SQLException se) {
            throw new DAOException("Error adding in DAO");
        }
    }

    @Override
    public Cliente get(Connection con, String idCliente) throws DAOException {
        try (PreparedStatement stmt = con.prepareStatement(SELECTCLIENTE)) {
            stmt.setString(2, idCliente);
            ResultSet rs = stmt.executeQuery();

            return new Cliente(rs.getString("ID_CLIENTE"), rs.getString("DNI"), rs.getString("Nombre"), rs.getString("Direccion"), rs.getString("Poblacion"), rs.getString("Telf"));
        } catch (SQLException se) {
            throw new DAOException("Error getting all Clients in DAO");
        }
    }

}
