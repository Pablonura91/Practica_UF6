/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.model.Cliente;
import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public interface ClienteDAO {
    public ArrayList<Cliente> list (Connection con) throws DAOException;
    public void add (Connection con, Cliente cliente) throws DAOException;
    public Cliente get (Connection con, String idCliente) throws DAOException;
}
