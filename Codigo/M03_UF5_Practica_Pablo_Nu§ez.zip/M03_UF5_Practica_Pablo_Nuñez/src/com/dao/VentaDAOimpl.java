/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.model.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class VentaDAOimpl implements VentaDAO {

    private static final String QUERYGETVENTAS = "SELECT v.*, p.* FROM ventas v, productos p WHERE v.ID_Cliente = ?";
    private static final String INSERTVENTA = "INSERT INTO VENTAS VALUES(NULL,?, now());";
    private static final String INSERTLINEAVENTA = "INSERT INTO `lineaventas`(`ID_lineaVenta`, `ID_Producto`, `ID_Venta`) VALUES (NULL, ?, (SELECT ID_Venta FROM ventas ORDER BY ID_Venta DESC LIMIT 1))";
    private static final String SELECTTOPTEN = "SELECT c.Nombre, c.ID_Cliente, SUM(pro.PVP) AS precio FROM productos AS pro, lineaventas AS lv, ventas AS v, clientes AS c WHERE pro.ID_Producto = lv.ID_Producto AND lv.ID_Venta = v.ID_Venta AND v.ID_Cliente = c.ID_Cliente GROUP BY c.ID_Cliente ORDER BY precio DESC LIMIT 10";

    @Override
    public ArrayList<Venta> list(Connection con, int id) throws DAOException {
        try (PreparedStatement stmt = con.prepareStatement(QUERYGETVENTAS)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            ArrayList<Venta> venta = new ArrayList<>();

            while (rs.next()) {
                venta.add(new Venta(rs.getString("IDCLIENTE"), rs.getInt("IDPRODUCTO"), rs.getString("Descripcion"), rs.getInt("CANTIDAD")));
            }

            return venta;
        } catch (SQLException se) {
            throw new DAOException("Error getting all Clients in DAO");
        }
    }

    @Override
    public void add(ArrayList<Venta> carrito, Connection con, int IDCliente) throws DAOException {
            insertVenta(con, IDCliente);
            insertProductoToLineaVenta(con, carrito);
        }

    private void insertProductoToLineaVenta(Connection con, ArrayList<Venta> carrito) throws DAOException {
        try (PreparedStatement stmt = con.prepareStatement(INSERTLINEAVENTA)) {
            for (Venta venta : carrito) {
                stmt.setInt(1, venta.getIdProducto());
                if (stmt.executeUpdate() != 1) {
                    throw new DAOException("Error adding venta");
                }
            }
        } catch (SQLException se) {
            throw new DAOException("Error adding in DAO");
        }
    }

    private void insertVenta(Connection con, int IDCliente) throws DAOException{
        try (PreparedStatement stmt = con.prepareStatement(INSERTVENTA)) {
            stmt.setInt(1, IDCliente);

            if (stmt.executeUpdate() != 1) {
                throw new DAOException("Error adding venta");
            }
        } catch (SQLException se) {
            throw new DAOException("Error adding in DAO");
        }
    }

    @Override
    public ArrayList<String> viewTopTen(Connection con) throws DAOException{
        try (Statement stmt = con.createStatement()) {
            ResultSet rs = stmt.executeQuery(SELECTTOPTEN);
            ArrayList<String> venta = new ArrayList<>();
            while (rs.next()) {
                venta.add("Cliente: " + rs.getString("NOMBRE") +" "+ rs.getInt("precio") +"€");
            }

            return venta;
        } catch (SQLException se) {
            throw new DAOException("Error getting all Venta in DAO");
        }
    }
}
