/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.dao.ClienteDAO;
import com.dao.ClienteDAOFactory;
import com.dao.DAOException;
import com.jdbc.utilities.singeltonConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

/**
 * @author Pablo
 */
public class Cliente {

    private String id;
    private String dni;
    private String nombre;
    private String direccion;
    private String poblacion;
    private String telefono;
    private String date;

    public Cliente(String id, String dni, String nombre, String direccion, String poblacion, String telefono) {
        this.id = id;
        this.dni = dni;
        this.nombre = nombre;
        this.direccion = direccion;
        this.poblacion = poblacion;
        this.telefono = telefono;
    }

    public Cliente(String dni, String nombre, String direccion, String poblacion, String telefono, String date, int i) {
        this.dni = dni;
        this.nombre = nombre;
        this.direccion = direccion;
        this.poblacion = poblacion;
        this.telefono = telefono;
        this.date = date;
    }

    public Cliente() {
    }

    //Metodo para confirmar login
    public Cliente login(String nombre, char[] passwordField) throws SQLException, DAOException {
        Cliente cliente = new Cliente();
        ArrayList<Cliente> clientes = list();
        for (Cliente c : clientes) {
            if (c.nombre.equalsIgnoreCase(nombre) && isPasswordCorrect(passwordField, c.dni.toCharArray())) {
                cliente = new Cliente(c.id, c.dni, c.nombre, c.direccion, c.poblacion, c.telefono);
            }
        }
        return cliente;
    }

    //Metodo que carga todos los clientes que existen en la BBDD
    public ArrayList<Cliente> list() throws SQLException, DAOException {
        Connection con = singeltonConnection.getInstance();
        ClienteDAOFactory factoryCliente = new ClienteDAOFactory();
        ClienteDAO daoCliente = factoryCliente.createClienteDAO();
        ArrayList<Cliente> clientes = new ArrayList<>();
        clientes = daoCliente.list(con);

        try {
            singeltonConnection.closeConnection();
        } catch (SQLException e) {
            System.out.println("Error closing resource " + e.getClass().getName());
        }

        return clientes;
    }

    //Metodo para poder crear nuevos usuarios
    public void crearUsuario(String dni, String nombre, String direccion, String poblacion, String telefono, String date) throws SQLException, DAOException {
        ClienteDAOFactory factoryCliente = new ClienteDAOFactory();
        ClienteDAO daoCliente = factoryCliente.createClienteDAO();

        Connection con = singeltonConnection.getInstance();
        daoCliente.add(con, new Cliente(dni, nombre, direccion, poblacion, telefono, date, 1));

    }

    private static boolean isPasswordCorrect(char[] input, char[] password) {
        boolean isCorrect = true;

        if (input.length != password.length) {
            isCorrect = false;
        } else {
            isCorrect = Arrays.equals(input, password);
        }

        //Zero out the password.
        Arrays.fill(password, '0');

        return isCorrect;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getDate() {
        return date;
    }
}
