/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.dao.DAOException;
import com.dao.VentaDAO;
import com.dao.VentaDAOFactory;
import com.jdbc.utilities.singeltonConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Pablo
 */
public class Venta {

    private int idProducto;
    private String nombreProducto;
    private int cantidad;

    private java.util.Date utilDate = new java.util.Date();

    private java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

    public Venta(String idVenta, int idProducto, String descripcion, int cantidad) {
        this.idProducto = idProducto;
        this.nombreProducto = descripcion;
        DateFormat df = new SimpleDateFormat("dd/MM/YYYY - hh:mm:ss");
        String fechaVenta = df.format(utilDate);
        this.cantidad = cantidad;
    }

    public Venta() {
    }

    public int getIdProducto() {
        return idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    //Metodo que sirve para cerrar una venta de un cliente
    public void cerrarVenta(ArrayList<Venta> carrito, int IDCliente) throws SQLException, DAOException {
        VentaDAOFactory factoryVenta = new VentaDAOFactory();
        VentaDAO daoVenta = VentaDAOFactory.createVentaDAO();
        Connection con = singeltonConnection.getInstance();
        daoVenta.add(carrito, con, IDCliente);
    }

    public ArrayList<String> viewTopTen() throws SQLException, DAOException {
        VentaDAOFactory factoryVenta = new VentaDAOFactory();
        VentaDAO daoVenta = VentaDAOFactory.createVentaDAO();
        ArrayList<String> historicoCliente = new ArrayList<>();
        Connection con = singeltonConnection.getInstance();
        historicoCliente = daoVenta.viewTopTen(con);

        return historicoCliente;
    }
}
