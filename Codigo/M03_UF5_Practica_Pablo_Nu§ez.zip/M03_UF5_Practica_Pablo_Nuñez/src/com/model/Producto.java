/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.dao.DAOException;
import com.dao.ProductoDAO;
import com.dao.ProductoDAOFactory;
import com.jdbc.utilities.singeltonConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @author Pablo
 */
public class Producto {

    private int id;
    private String descripcion;
    private int stockActual;
    private Double pvp;

    public Producto(int id, String descripcion, int stockActual, Double pvp) {
        this.id = id;
        this.descripcion = descripcion;
        this.stockActual = stockActual;
        this.pvp = pvp;
    }

    public Producto(String descripcion, int stockActual, Double pvp) {
        this.descripcion = descripcion;
        this.stockActual = stockActual;
        this.pvp = pvp;
    }

    public Producto() {
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getStock(){return stockActual;}

    public Double getPvp() {
        return pvp;
    }

    //Metodo que se utiliza para pasar todos los productos que existen en la BBDD a un ArrayList
    public ArrayList<Producto> list() throws SQLException, DAOException {
        Connection con = singeltonConnection.getInstance();
        ProductoDAOFactory factoryProducto = new ProductoDAOFactory();
        ProductoDAO daoProducto = factoryProducto.createProductoDAO();
        ArrayList<Producto> allProductos = new ArrayList<>();
        allProductos = daoProducto.list(con);
        try {
            singeltonConnection.closeConnection();
        } catch (SQLException e) {
            System.out.println("Error closing resource " + e.getClass().getName());
        }

        return allProductos;
    }

    public void add(Producto producto) throws SQLException, DAOException {
        ProductoDAOFactory factoryVenta = new ProductoDAOFactory();
        ProductoDAO daoProducto = ProductoDAOFactory.createProductoDAO();
        Connection con = singeltonConnection.getInstance();
        daoProducto.add(producto, con);
    }
}
