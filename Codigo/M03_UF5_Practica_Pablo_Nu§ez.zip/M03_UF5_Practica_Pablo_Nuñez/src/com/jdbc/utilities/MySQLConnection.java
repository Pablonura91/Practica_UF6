/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.utilities;

/**
 *
 * @author Pablo
 */
public class MySQLConnection {
    public static String url="jdbc:mysql://localhost:3306/exercicif603";
    public static String user="root";
    public static String password="";
    
}
