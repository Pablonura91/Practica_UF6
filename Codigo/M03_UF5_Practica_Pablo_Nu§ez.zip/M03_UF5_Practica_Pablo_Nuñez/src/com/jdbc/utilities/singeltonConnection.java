/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jdbc.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Pablo
 */
public class singeltonConnection {

    private static Connection instance;

    private singeltonConnection() {
    }

    public static Connection getInstance() throws SQLException {
        if (instance == null) {
            instance = DriverManager.getConnection(MySQLConnection.url, MySQLConnection.user, MySQLConnection.password);
            System.out.println("Open Database");
        }
        return instance;
    }

    public static void closeConnection() throws SQLException {
        if (instance != null) {
            instance.close();
            instance = null;
            System.out.println("Database Closed");
        }
    }
}
