/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vista;

import com.controller.BotigaController;
import com.controller.ButtonProductoController;

import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Pablo
 */
public class BotigaView extends JFrame {

    //Grid
    private final JPanel panelGrid = new JPanel();
    private final JPanel panelUp = new JPanel();
    private final JPanel panelDown = new JPanel();
    //Components
    private JTextField clientSel;
    private JButton JBSelClient, JBCarrito, JBHistorico, JBcreateProducto;
    private JButton JBProducto;

    private static String IdCliente;

    public BotigaView() {

        this.setTitle("Botiga");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        addComponentsToPane();

        this.setPreferredSize(new Dimension(1500, 750));
        this.setResizable(false);

        this.pack();
        this.setVisible(true);
    }

    void addComponentsToPane() {             
        
        //Carga la todas las compras que ha hecho un comprador
        JBCarrito = new JButton("Carrito");
        JBCarrito.setPreferredSize(new Dimension(200, 30));

        JBCarrito.setBounds(10, 10, 400, 30);
        panelUp.add(JBCarrito);

        clientSel = new JTextField("");
        clientSel.setPreferredSize(new Dimension(200, 30));
        clientSel.setEditable(false);
        clientSel.setBackground(Color.white);
        clientSel.setBounds(300, 10, 200, 30);
        panelUp.add(clientSel);

        JBcreateProducto = new JButton("Crear producto");
        JBcreateProducto.setPreferredSize(new Dimension(180, 30));
        JBcreateProducto.setBounds(600, 10, 200, 30);
        panelUp.add(JBcreateProducto);

        JBHistorico = new JButton("Ver Top 10 ventas por cliente");
        JBHistorico.setPreferredSize(new Dimension(180, 30));
        JBHistorico.setBounds(700, 10, 400, 30);
        panelUp.add(JBHistorico);
        this.add(panelUp, BorderLayout.NORTH);

    }

    public void addListeners(BotigaController controller) {
        JBCarrito.addActionListener(controller);
        JBcreateProducto.addActionListener(controller);
        JBHistorico.addActionListener(controller);
        panelGrid.setSize(1450, 500);
        this.add(panelGrid, BorderLayout.SOUTH);
    }

    public void addListenerProducto(ButtonProductoController controller){
        JBProducto.addActionListener(controller);
    }

//--------------------------------------------------------------------------

    public JButton getJBCarrito() {
        return JBCarrito;
    }
    
    public JButton getCreateProducto() {
        return JBcreateProducto;
    }

    public JButton getHistoricoButton() {
        return JBHistorico;
    }

    public JButton getJBProducto() {
        return JBProducto  = new JButton();
    }

    public void setJTextClientSel(String client) {
        this.clientSel.setText(client);
    }

    public JPanel getPanelGrid() {
        return panelGrid;
    }
}
