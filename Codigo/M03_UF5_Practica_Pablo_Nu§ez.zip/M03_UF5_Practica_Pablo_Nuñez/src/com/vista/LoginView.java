/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vista;

import com.controller.BotigaController;
import com.controller.LoginController;
import com.dao.DAOException;
import com.model.Cliente;
import com.model.Producto;
import com.model.Venta;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Pablo
 */
public class LoginView extends JFrame {

    private JLabel jLabelLogin, jLabelUserName, jLabelPassword, jLabelErrUserName, jLabelErrPassword;
    private JTextField textFieldUserName;
    private JButton jButtonLogin, jButtonNuevoUsuario;
    private JPasswordField jFieldPassword;
    private Color red = new Color(255, 0, 0);

    public LoginView() {
        jLabelLogin = new JLabel("");

        addComponentsLoginToFrame();

        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
    }
    
    private void addComponentsLoginToFrame() {
        jLabelUserName = new JLabel("Username");
        jLabelErrUserName = new JLabel();
        jLabelErrUserName.setForeground(red);
        jLabelPassword = new JLabel("Password (DNI)");
        jLabelErrPassword = new JLabel();
        jLabelErrPassword.setForeground(red);
        textFieldUserName = new JTextField();
        jFieldPassword = new JPasswordField();
        
        
        jLabelLogin.setBounds(100, 30, 400, 30);
        jLabelUserName.setBounds(80, 70, 200, 30);
        jLabelErrUserName.setBounds(300, 90, 200, 30);
        jLabelErrPassword.setBounds(300, 140, 200, 30);
        jLabelPassword.setBounds(80, 120, 200, 30);
        textFieldUserName.setBounds(300, 70, 200, 30);
        jFieldPassword.setBounds(300, 120, 200, 30);

        this.add(jLabelLogin);
        this.add(jLabelUserName);
        this.add(jLabelErrUserName);
        this.add(jLabelErrPassword);
        this.add(textFieldUserName);
        this.add(jLabelPassword);
        this.add(jFieldPassword);

        jButtonLogin = new JButton("login");
        createButtons(jButtonLogin, "login", new int[]{150, 170, 100, 30});
        this.add(jButtonLogin);
          
        jButtonNuevoUsuario = new JButton("Crear usuario");
        createButtons(jButtonNuevoUsuario, "crear", new int[]{300, 170, 150, 30});  

        
        this.setSize(600, 400);
    }
    
    private void createButtons(JButton button, String comand, int[] posicion){  
        button.setActionCommand(comand);
        button.setBounds(posicion[0], posicion[1], posicion[2], posicion[3]);
        this.add(button);
    }
    
    public void setActionListener(ActionListener controller){
        jButtonLogin.addActionListener(controller);
        jButtonNuevoUsuario.addActionListener(controller);
    }

    public JTextField getTextFieldUserName() {
        return textFieldUserName;
    }
    
    public JPasswordField getjFieldPassword() {
        return jFieldPassword;
    }
    
    

    public JLabel getjLabelErrUserName() {
        return jLabelErrUserName;
    }

    public JLabel getjLabelErrPassword() {
        return jLabelErrPassword;
    }
}
