package com.vista;

import javax.swing.*;

import java.awt.event.ActionListener;

import static java.awt.Color.red;

public class ProductoView extends JFrame {
    private JLabel jLabelDescripcion, jLabelErrDescripcion, jLabelStock, jLabelErrStock, jLabelPVP, jLabelErrPVP;
    private JTextField jTextFielDescripcion, jTextFieldStock, jTextFieldPVP;
    private JButton jButtonCrearProducto, jButtonCancelar;

    public ProductoView(){
        addComponentsToPaneNewProducto();

        this.setDefaultCloseOperation(this.DO_NOTHING_ON_CLOSE);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
    }

    //Frame para crear un nuevo usuario
    private void addComponentsToPaneNewProducto() {
        jLabelDescripcion = new JLabel("Descripcion");
        jTextFielDescripcion = new JTextField();
        jLabelErrDescripcion = new JLabel();
        jLabelErrDescripcion.setForeground(red);

        jLabelStock = new JLabel("Stock");
        jTextFieldStock = new JTextField();
        jLabelErrStock = new JLabel();
        jLabelErrStock.setForeground(red);

        jLabelPVP = new JLabel("PVP");
        jTextFieldPVP = new JTextField();
        jLabelErrPVP = new JLabel();
        jLabelErrPVP.setForeground(red);

        jLabelDescripcion.setBounds(50, 2, 100, 30);
        jTextFielDescripcion.setBounds(150, 2, 200, 30);
        jLabelErrDescripcion.setBounds(150, 22, 200, 30);

        jLabelStock.setBounds(50, 52, 100, 30);
        jTextFieldStock.setBounds(150, 52, 200, 30);
        jLabelErrStock.setBounds(150, 72, 200, 30);

        jLabelPVP.setBounds(50, 102, 100, 30);
        jTextFieldPVP.setBounds(150, 102, 200, 30);
        jLabelErrPVP.setBounds(150, 122, 200, 30);

        this.add(jTextFielDescripcion);
        this.add(jLabelDescripcion);
        this.add(jTextFielDescripcion);
        this.add(jLabelStock);
        this.add(jTextFieldStock);
        this.add(jLabelPVP);
        this.add(jTextFieldPVP);
        this.add(jLabelErrDescripcion);
        this.add(jLabelErrPVP);
        this.add(jLabelErrStock);

        jButtonCrearProducto = new JButton("Crear producto");
        createButtons(jButtonCrearProducto, "crear", new int[]{100, 282, 200, 30});

        jButtonCancelar = new JButton("Cancelar");
        createButtons(jButtonCancelar, "cancelar", new int[]{100, 320, 200, 30});

        this.setSize(420, 400);
    }

    private void createButtons(JButton button, String comand, int[] posicion){
        button.setActionCommand(comand);
        button.setBounds(posicion[0], posicion[1], posicion[2], posicion[3]);
        this.add(button);
    }

    public void setActionListener(ActionListener controller){
        jButtonCrearProducto.addActionListener(controller);
        jButtonCancelar.addActionListener(controller);
    }

    public JTextField getjTextFielDescripcion() {
        return jTextFielDescripcion;
    }

    public JTextField getjTextFieldStock() {
        return jTextFieldStock;
    }

    public JTextField getjTextFieldPVP() {
        return jTextFieldPVP;
    }

    public JLabel getjLabelDescripcion() {
        return jLabelDescripcion;
    }

    public JLabel getjLabelErrDescripcion() {
        return jLabelErrDescripcion;
    }

    public JLabel getjLabelStock() {
        return jLabelStock;
    }

    public JLabel getjLabelErrStock() {
        return jLabelErrStock;
    }

    public JLabel getjLabelPVP() {
        return jLabelPVP;
    }

    public JLabel getjLabelErrPVP() {
        return jLabelErrPVP;
    }
}
