/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vista;

import com.controller.UsuarioConroller;
import static java.awt.Color.red;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author pablo
 */
public class UsuarioView extends JFrame{
    
    private JLabel jLabelDNI, jLabelErrDNI, jLabelNombre, jLabelErrNombre, jLabelDireccion, jLabelErrDireccion, jLabelPoblacion, jLabelErrPoblacion, jLabelTelefono, jLabelErrTelefono;
    private JTextField jTextFieldDNI, jTextFieldnombre, jTextFielddireccion, jTextFieldpoblacion, jTextFieldtelefono;
    private JButton jButtonCrearUsuario, jButtonCancelar;
    
    public UsuarioView(){
        addComponentsToPaneNewUser();
        
        this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
    }
    
    //Frame para crear un nuevo usuario
    private void addComponentsToPaneNewUser() {
        jLabelDNI = new JLabel("DNI");
        jTextFieldDNI = new JTextField();
        jLabelErrDNI = new JLabel();
        jLabelErrDNI.setForeground(red);

        jLabelNombre = new JLabel("Nombre");
        jTextFieldnombre = new JTextField();
        jLabelErrNombre = new JLabel();
        jLabelErrNombre.setForeground(red);

        jLabelDireccion = new JLabel("Direccion");
        jTextFielddireccion = new JTextField();
        jLabelErrDireccion = new JLabel();
        jLabelErrDireccion.setForeground(red);

        jLabelPoblacion = new JLabel("Poblacion");
        jTextFieldpoblacion = new JTextField();
        jLabelErrPoblacion = new JLabel();
        jLabelErrPoblacion.setForeground(red);

        jLabelTelefono = new JLabel("Telefono");
        jTextFieldtelefono = new JTextField();
        jLabelErrTelefono = new JLabel();
        jLabelErrTelefono.setForeground(red);

        jLabelDNI.setBounds(50, 2, 100, 30);
        jTextFieldDNI.setBounds(150, 2, 200, 30);
        jLabelErrDNI.setBounds(150, 22, 200, 30);

        jLabelNombre.setBounds(50, 52, 100, 30);
        jTextFieldnombre.setBounds(150, 52, 200, 30);
        jLabelErrNombre.setBounds(150, 72, 200, 30);

        jLabelDireccion.setBounds(50, 102, 100, 30);
        jTextFielddireccion.setBounds(150, 102, 200, 30);
        jLabelErrDireccion.setBounds(150, 122, 200, 30);

        jLabelPoblacion.setBounds(50, 152, 100, 30);
        jTextFieldpoblacion.setBounds(150, 152, 200, 30);
        jLabelErrPoblacion.setBounds(150, 172, 200, 30);

        jLabelTelefono.setBounds(50, 202, 100, 30);
        jTextFieldtelefono.setBounds(150, 202, 200, 30);
        jLabelErrTelefono.setBounds(150, 222, 200, 30);
                
        this.add(jTextFieldDNI);
        this.add(jLabelDNI);
        this.add(jTextFieldDNI);
        this.add(jLabelNombre);
        this.add(jTextFieldnombre);
        this.add(jLabelDireccion);
        this.add(jTextFielddireccion);
        this.add(jLabelPoblacion);
        this.add(jTextFieldpoblacion);
        this.add(jLabelTelefono);
        this.add(jTextFieldtelefono);
        this.add(jLabelErrDNI);
        this.add(jLabelErrDireccion);
        this.add(jLabelErrNombre);
        this.add(jLabelErrPoblacion);
        this.add(jLabelErrTelefono);        
        
        jButtonCrearUsuario = new JButton("Crear usuario");
        createButtons(jButtonCrearUsuario, "crear", new int[]{100, 282, 200, 30});  
        
        jButtonCancelar = new JButton("Cancelar");
        createButtons(jButtonCancelar, "cancelar", new int[]{100, 320, 200, 30});  
        
        this.setSize(420, 400);
    }
    
    private void createButtons(JButton button, String comand, int[] posicion){  
        button.setActionCommand(comand);
        button.setBounds(posicion[0], posicion[1], posicion[2], posicion[3]);
        this.add(button);
    }
    
    public void setActionListener(ActionListener controller){
        jButtonCrearUsuario.addActionListener(controller);
        jButtonCancelar.addActionListener(controller);
    }
    
    
    public JTextField getjTextFieldDNI() {
        return jTextFieldDNI;
    }

    public JTextField getjTextFieldNombre() {
        return jTextFieldnombre;
    }

    public JTextField getjTextFielddireccion() {
        return jTextFielddireccion;
    }

    public JTextField getjTextFieldpoblacion() {
        return jTextFieldpoblacion;
    }

    public JTextField getjTextFieldtelefono() {
        return jTextFieldtelefono;
    }

    public JLabel getjLabelErrDNI() {
        return jLabelErrDNI;
    }

    public JLabel getjLabelErrNombre() {
        return jLabelErrNombre;
    }

    public JLabel getjLabelErrDireccion() {
        return jLabelErrDireccion;
    }

    public JLabel getjLabelErrPoblacion() {
        return jLabelErrPoblacion;
    }

    public JLabel getjLabelErrTelefono() {
        return jLabelErrTelefono;
    }

}
