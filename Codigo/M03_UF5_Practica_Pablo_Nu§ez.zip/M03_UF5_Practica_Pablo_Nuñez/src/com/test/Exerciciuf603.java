/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import com.controller.BotigaController;
import com.controller.LoginController;
import com.model.Cliente;
import com.model.Producto;
import com.model.Venta;
import com.vista.BotigaView;
import com.vista.LoginView;

/**
 *
 * @author Pablo
 */
public class Exerciciuf603 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        initLogin();
    }        
    private static void initLogin(){
        LoginController loginController = new LoginController(new Cliente(), new LoginView());
    }
}
