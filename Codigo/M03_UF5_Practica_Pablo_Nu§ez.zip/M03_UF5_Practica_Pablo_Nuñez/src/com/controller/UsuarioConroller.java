/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.dao.DAOException;
import com.model.Cliente;
import com.vista.LoginView;
import com.vista.UsuarioView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * @author pablo
 */
public class UsuarioConroller implements ActionListener {

    private UsuarioView usuarioView;
    private Cliente cliente;
    private final String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());

    UsuarioConroller(Cliente cliente, UsuarioView usuarioView) {
        this.usuarioView = usuarioView;
        this.cliente = cliente;

        usuarioView.setActionListener(this);
        usuarioView.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("crear")) {
            try {
                if (isInputsOK()) {
                    cliente.crearUsuario(usuarioView.getjTextFieldDNI().getText(), usuarioView.getjTextFieldNombre().getText(), usuarioView.getjTextFielddireccion().getText(), usuarioView.getjTextFieldpoblacion().getText(), usuarioView.getjTextFieldtelefono().getText(), timeStamp);
                    JOptionPane.showMessageDialog(new JFrame(), "Usuario Creado", "Dialog",
                            JOptionPane.ERROR_MESSAGE);
                    usuarioView.setVisible(false);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(new JFrame(), ex, "Dialog",
                        JOptionPane.ERROR_MESSAGE);
            } catch (DAOException ex) {
                Logger.getLogger(LoginView.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getActionCommand().equals("cancelar")) {
            try {
                usuarioView.setVisible(false);
            } catch (Exception ex) {
                Logger.getLogger(LoginView.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private boolean isInputsOK() {
        boolean isOk = false;

        if (dniIsOk(usuarioView.getjTextFieldDNI().getText())) {
            isOk = true;
        } else {
            usuarioView.getjLabelErrDNI().setText("*DNI mal introducido");
            isOk = false;
        }

        if (nombreIsOk(usuarioView.getjTextFieldNombre().getText())) {
            isOk = true;
        } else {
            usuarioView.getjLabelErrNombre().setText("*Nombre mal introducido");
            isOk = false;
        }

        if (direccionIsOk(usuarioView.getjTextFielddireccion().getText())) {
            isOk = true;
        } else {
            usuarioView.getjLabelErrDireccion().setText("*Direccion mal introducido");
            isOk = false;
        }

        if (poblacionIsOk(usuarioView.getjTextFieldpoblacion().getText())) {
            isOk = true;
        } else {
            usuarioView.getjLabelErrPoblacion().setText("*Poblacion mal introducido");
            isOk = false;
        }

        if (telefonoIsOk(usuarioView.getjTextFieldtelefono().getText())) {
            isOk = true;
        } else {
            usuarioView.getjLabelErrTelefono().setText("*Telefono mal introducido");
            isOk = false;
        }

        return isOk;
    }

    private boolean dniIsOk(String dni) {
        String dniRegexp = "\\d{8}[A-HJ-NP-TV-Z]";

        return Pattern.matches(dniRegexp, dni);
    }

    private boolean nombreIsOk(String text) {
        return text.matches("[a-zA-Z]+");
    }

    private boolean direccionIsOk(String text) {
        return text.matches("[a-zA-Z1-9]+");
    }

    private boolean poblacionIsOk(String text) {
        return text.matches("[a-zA-Z1-9]+");
    }

    private boolean telefonoIsOk(String text) {
        return text.matches("[1-9]+");
    }
}
