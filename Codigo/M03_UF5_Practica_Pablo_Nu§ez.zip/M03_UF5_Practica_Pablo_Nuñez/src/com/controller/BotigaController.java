/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.dao.DAOException;
import com.model.Cliente;
import com.model.Producto;
import com.model.Venta;
import com.vista.BotigaView;
import com.vista.ProductoView;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class BotigaController implements ActionListener {

    private Cliente cliente;
    private Producto producto;
    private Venta venta;
    private BotigaView viewBotiga;

    //ArrayList donde se guardaran los productos a comprar
    private static ArrayList<Venta> carrito = new ArrayList<>();

    BotigaController(Cliente cliente) {
        this.cliente = cliente;
        this.producto = new Producto();
        this.venta = new Venta();
        this.viewBotiga = new BotigaView();

        viewBotiga.addListeners(this);
        addProduct();
        viewBotiga.setJTextClientSel(cliente.getNombre());
    }

    private void addProduct() {
        viewBotiga.setLayout(new GridLayout(4, 4));
        viewBotiga.add(viewBotiga.getPanelGrid());

        try {
            ArrayList<Producto> allProductos = producto.list();
            for (Producto p : allProductos) {
                JButton JBProducto = viewBotiga.getJBProducto();
                //JBProducto = new JButton(p.getDescripcion());
                JBProducto.setText(p.getDescripcion() + "  " + p.getPvp() + "€");
                JBProducto.setPreferredSize(new Dimension(150, 50));
                new ButtonProductoController(viewBotiga,"", p.getId(), p.getDescripcion(), 1);
                viewBotiga.getPanelGrid().add(JBProducto);
            }
            viewBotiga.add(viewBotiga.getPanelGrid(), BorderLayout.SOUTH);
        } catch (SQLException | DAOException ex) {
            Logger.getLogger(BotigaView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == viewBotiga.getCreateProducto()) {
            viewBotiga.setVisible(false);
            ProductoController productoController = new ProductoController(new Producto(), new ProductoView(), cliente);
        }
        if (ae.getSource() == viewBotiga.getHistoricoButton()) {
            JFrame JFrameHistoricoCliente = new JFrame();
            JFrameHistoricoCliente.setLayout(new FlowLayout());
            JFrameHistoricoCliente.setPreferredSize(new Dimension(500, 500));
            JFrameHistoricoCliente.setResizable(false);
            JTextArea historico = new JTextArea();
            historico.setPreferredSize(new Dimension(500, 500));
            historico.setEditable(false);
            JFrameHistoricoCliente.add(historico);
            ArrayList<String> allVentaCliente;
            String cadena = "";
            try {
                StringBuilder listaClientes = new StringBuilder();
                allVentaCliente = venta.viewTopTen();
                for (String ventaCliente : allVentaCliente) {
                    listaClientes.append(ventaCliente).append("\n");
                }
                historico.setText(listaClientes.toString());
            } catch (SQLException | DAOException ex) {
                Logger.getLogger(BotigaController.class.getName()).log(Level.SEVERE, null, ex);
            }
            historico.setVisible(true);
            JFrameHistoricoCliente.pack();
            JFrameHistoricoCliente.setVisible(true);
        }
        if (ae.getSource() == viewBotiga.getJBCarrito()) {
            String cadena = "";

            JFrame selecCarrito = new JFrame();
            selecCarrito.setLayout(new FlowLayout());
            selecCarrito.setPreferredSize(new Dimension(500, 600));
            selecCarrito.setResizable(false);
            JTextArea productosToCarrito = new JTextArea();
            productosToCarrito.setPreferredSize(new Dimension(400, 400));
            for (Venta v : carrito) {
                cadena += /*"ID producto " + v.getIdProducto() + */"Producto " + v.getNombreProducto() + " Cantidad" + v.getCantidad() + "\n";
                productosToCarrito.setText(cadena);
            }
            productosToCarrito.setVisible(true);
            selecCarrito.add(productosToCarrito);

            //Boton para  cerrar una compra
            JButton vender = new JButton("Comprar");
            vender.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        venta.cerrarVenta(carrito, Integer.parseInt(cliente.getId()));
                        carrito.clear();
                        selecCarrito.setVisible(false);
                    } catch (SQLException | DAOException ex) {
                        Logger.getLogger(BotigaView.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            selecCarrito.add(vender);
            selecCarrito.pack();
            selecCarrito.setVisible(true);
        }
    }

    static ArrayList<Venta> getCarrito() {
        return carrito;
    }
}
