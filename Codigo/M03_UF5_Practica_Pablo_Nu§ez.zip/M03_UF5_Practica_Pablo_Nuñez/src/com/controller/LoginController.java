/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.dao.DAOException;
import com.model.Cliente;
import com.model.Producto;
import com.model.Venta;
import com.vista.BotigaView;
import com.vista.LoginView;
import com.vista.UsuarioView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author pablo
 */
public class LoginController implements ActionListener {

    private LoginView loginView;

    public LoginController(Cliente cliente, LoginView loginView) {
        this.loginView = loginView;
        loginView.setActionListener(this);
        loginView.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("login")) {
            try {
                Cliente cliente = new Cliente();
                cliente = cliente.login(loginView.getTextFieldUserName().getText(), loginView.getjFieldPassword().getPassword());

                char[] pass = loginView.getjFieldPassword().getPassword();
                if (cliente.getId() != null) {
                    loginView.getTextFieldUserName().setText("");
                    loginView.getjFieldPassword().setText("");
                    BotigaController controllerBotiga = new BotigaController(cliente);

                } else {
                    loginView.getjLabelErrUserName().setText("*Usuario no existe!");
                    loginView.getjLabelErrPassword().setText("*La contraseña es incorrecta!");
                }
            } catch (SQLException | DAOException ex) {
                Logger.getLogger(LoginView.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getActionCommand().equals("crear")) {
            UsuarioConroller controller = new UsuarioConroller(new Cliente(), new UsuarioView());
        }
    }
}
