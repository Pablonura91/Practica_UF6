package com.controller;

import com.dao.DAOException;
import com.model.Cliente;
import com.model.Producto;
import com.vista.ProductoView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class ProductoController implements ActionListener {
    private ProductoView productoView;
    private Producto producto;
    private Cliente cliente;

    public ProductoController(Producto producto, ProductoView productoView, Cliente cliente) {
        this.productoView = productoView;
        this.producto = producto;
        this.cliente = cliente;

        productoView.setActionListener(this);
        productoView.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("crear")) {
            try {
                if (isInputsOK()) {
                    producto.add(new Producto(productoView.getjTextFielDescripcion().getText(), Integer.parseInt(productoView.getjTextFieldStock().getText()), Double.parseDouble(productoView.getjTextFieldPVP().getText())));
                    JOptionPane.showMessageDialog(new JFrame(), "Producto Creado", "Dialog",
                            JOptionPane.ERROR_MESSAGE);

                    productoView.setVisible(false);
                    new BotigaController(cliente);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(new JFrame(), ex, "Dialog",
                        JOptionPane.ERROR_MESSAGE);
            } catch (DAOException e1) {
                e1.printStackTrace();
            } finally {
            }
        } else if (e.getActionCommand().equals("cancelar")) {
            try {
                productoView.setVisible(false);
                new BotigaController(cliente);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private boolean isInputsOK() {
        boolean isOk;

        if (!productoView.getjTextFielDescripcion().getText().isEmpty()) {
            isOk = true;
        } else {
            productoView.getjLabelErrDescripcion().setText("*Descripcion mal introducido");
            isOk = false;
        }

        if (isNumber(productoView.getjTextFieldStock().getText())) {
            if (isOk) {
                isOk = true;
            }
        } else {
            productoView.getjLabelErrStock().setText("*Stock mal introducido");
            isOk = false;
        }

        if (isNumber(productoView.getjTextFieldPVP().getText())) {
            if (isOk) {
                isOk = true;
            }
        } else {
            productoView.getjLabelErrPVP().setText("*Precio mal introducido");
            isOk = false;
        }

        return isOk;
    }

    private boolean isNumber(String text) {
        return text.matches("^\\d+(\\.\\d{1,2})?$");
    }
}
