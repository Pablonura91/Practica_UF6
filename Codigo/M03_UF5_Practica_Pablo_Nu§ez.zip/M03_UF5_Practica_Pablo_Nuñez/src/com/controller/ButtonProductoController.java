package com.controller;

import com.model.Venta;
import com.vista.BotigaView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonProductoController implements ActionListener {
    private String id;
    private int idProducto;
    private String descripcion;
    private int cantidad;

    public ButtonProductoController(BotigaView viewBotiga, String id, int idProducto, String descripcion, int cantidad){
        this.id = id;
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        viewBotiga.addListenerProducto(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        BotigaController.getCarrito().add(new Venta(id, idProducto, descripcion, cantidad));
    }
}
